from django.urls import path
from django.contrib.auth import views as auth_views


from .import views

app_name='primary'

urlpatterns = [
    path('registerstudent/', views.register_student, name='registerstudent'),
    path('student/profile/', views.student_profile, name='studentprofile'),
    path('fees/', views.fees_dashboard, name='feesdashboard'),
    path('fees/set', views.set_fees, name='setfees'),
    path('fees/makepayment/', views.make_payment, name='makepayment'),
    path("payments/receipt/<str:invoice_number>/", views.payment_receipt, name="paymentreceipt"),
     path("create-payment/", views.create_payment, name="createpayment"),
     path("other-payment/", views.make_paymentother, name="otherpayment"),
    path("student/<str:studentid>/payments/", views.student_payments,
         name="studentpayments"),
    path("student-management/", views.student_management, name="studentmanagement"),
    path("student-management/new-year/", views.promote_students, name="promotestudents"),
    path("student-management/transfer/", views.transfer_student, name="transferstudent"),
    path('payment-analysis/', views.payment_analysis, name='paymentanalysis'),
     path('login/', views.login_view, name='login'),
     path('logout/', views.logout_view, name='logout'),



]