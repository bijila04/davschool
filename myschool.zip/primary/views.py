from django.shortcuts import render

# Create your views here.
from django.shortcuts import render, redirect
from django.shortcuts import render, get_object_or_404
from .models import Student, Payment, TypeofPayment,Fee,CreatePayment, ClassLevel
from django.db.models import Q
from django.utils import timezone
from decimal import Decimal, InvalidOperation
from django.contrib import messages
from django.db.models import F
from django.db.models import Sum
from django.contrib.auth import authenticate, login
from datetime import datetime

from django.shortcuts import render, redirect
from .models import Student
from django.contrib.auth import logout
from functools import wraps


def group_required(allowed_groups):
    """
    Decorator to grant access only to users in `allowed_groups`.
    Everyone else is redirected to their own “home” page.

    Usage:
        @group_required(["admin"])                 # admin-only
        @group_required(["admin", "clerk"])        # admin + clerk
    """
    def decorator(view_func):
        @wraps(view_func)
        def _wrapped(request, *args, **kwargs):
            # Not logged-in → login page
            if not request.user.is_authenticated:
                return redirect("primary:login")

            # In the allowed group?
            if request.user.groups.filter(name__in=allowed_groups).exists():
                return view_func(request, *args, **kwargs)

            # Otherwise: push to their landing page
            if request.user.groups.filter(name="secretary").exists():
                return redirect("primary:studentmanagement")
            if request.user.groups.filter(name="clerk").exists():
                return redirect("primary:feesdashboard")

            # Fallback for any other authenticated user (incl. admin)
            return redirect("primary:paymentanalysis")
        return _wrapped
    return decorator

def logout_view(request):
    logout(request)
    return redirect('core:index')

# primary/views.py

from django.contrib.auth.models import User, Group


def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            if user.groups.filter(name='admin').exists():
                return redirect('primary:paymentanalysis')
            elif user.groups.filter(name='clerk').exists():
                return redirect('primary:feesdashboard')
            elif user.groups.filter(name='secretary').exists():
                return redirect('primary:studentmanagement')
            else:
                return redirect('core:index')
                return redirect('')
        else:
            messages.error(request, 'Invalid username or password.')

    return render(request, 'primary/login.html')

def register_user(username, password, group_name):
    user = User.objects.create_user(username=username, password=password)
    group = Group.objects.get(name=group_name)
    user.groups.add(group)
    user.save()
    return user

@group_required(["admin"])
def payment_analysis(request):

    # Querying total payment amounts by month
    payments_by_month = Payment.objects.values('date__month').annotate(total_amount=Sum('amount')).order_by('date__month')

    # Querying payments by method
    payments_by_method = Payment.objects.values('method').annotate(total_amount=Sum('amount'))

    # Querying the total amount debited and credited
    debited_amount = Payment.objects.filter(effect='Debit').aggregate(total_debited=Sum('amount'))['total_debited'] or 0
    credited_amount = Payment.objects.filter(effect='Credit').aggregate(total_credited=Sum('amount'))['total_credited'] or 0

    # Preparing the data for the chart
    months = [datetime(2025, month, 1).strftime('%B') for month in range(1, 13)]
    payment_data = {month: 0 for month in months}
    for payment in payments_by_month:
        month_name = datetime(2025, payment['date__month'], 1).strftime('%B')
        payment_data[month_name] = payment['total_amount']

    # Get the payment methods and corresponding amounts
    methods = [payment['method'] for payment in payments_by_method]
    method_totals = [payment['total_amount'] for payment in payments_by_method]

    # Prepare data for debited vs credited chart
   
    # Prepare the data for the chart in a format that can be safely used in the template
    payment_data_values = list(payment_data.values())  # Convert to list for easier template use

    context = {
        'payment_data': payment_data,
        'payment_data_values': payment_data_values,  # Pass the values as a list
        'months': months,
        'methods': methods,
        'method_totals': method_totals,
        'debit': debited_amount,
        'credit': credited_amount,
    }

    return render(request, 'primary/paymentanalysis.html', context)


@group_required(["admin", "secretary"])
def student_management(request):
    return render(request, "primary/studentmanagement.html")


@group_required(["admin"])
def promote_students(request):
    students = Student.objects.filter(student_status="active")
    for student in students:
        student.level += 1
        if student.level > 6:
            student.student_status = "not active"
        student.save()
    return redirect("primary:studentmanagement")


@group_required(["admin"])
def transfer_student(request):
    student = None
    if request.method == "POST":
        student_id = request.POST.get("studentid")
        if "search" in request.POST:
            try:
                student = Student.objects.get(studentid=student_id)
                if student.student_status == "inactive":
                    messages.warning(request, "Student is already inactive.")
            except Student.DoesNotExist:
                messages.error(request, "Student with that ID not found.")

        elif "confirm_transfer" in request.POST:
            student = get_object_or_404(Student, studentid=student_id)
            student.student_status = "inactive"
            student.save()
            messages.success(request, f"{student.first_name} {student.last_name} has been transferred.")
            return redirect("primary:transferstudent")

    return render(request, "primary/transferstudent.html", {"student": student})



@group_required(["admin"])
def student_payments(request, studentid):
    """
    Shows all Debit & Credit records for one student.
    """
    student  = get_object_or_404(Student, studentid=studentid)
    payments = (Payment.objects
                       .filter(student=student)
                       .order_by("date", "id"))  # oldest→newest

    return render(request, "primary/studentpayments.html", {
        "student": student,
        "payments": payments,
        "today": timezone.now().date(),
    })



@group_required(["admin"])
def create_payment(request):
    """
    Page to create a bulk payment that can be applied to:
      • all students, or
      • only students in selected ClassLevels.
    """
    message = ""
    types   = TypeofPayment.objects.all()
    levels  = ClassLevel.objects.all()
    print(levels)

    if request.method == "POST":
        # ------------------------------------------------------------------ #
        # 1. Grab raw form data
        # ------------------------------------------------------------------ #
        name        = request.POST.get("name", "").strip()
        description = request.POST.get("description", "").strip()
        amount_raw  = request.POST.get("amount")
        type_id     = request.POST.get("typeofPayment")
        level_ids   = request.POST.getlist("levels")      # list of str IDs

        # ------------------------------------------------------------------ #
        # 2. Validate amount
        # ------------------------------------------------------------------ #
        try:
            amount = Decimal(amount_raw)
            if amount <= 0:
                raise ValueError
        except (InvalidOperation, ValueError, TypeError):
            return render(
                request,
                "primary/createpayment.html",
                {"message": "Invalid amount.", "types": types, "levels": levels},
            )

        # ------------------------------------------------------------------ #
        # 3. Validate payment type
        # ------------------------------------------------------------------ #
        try:
            payment_type = TypeofPayment.objects.get(id=type_id)
        except TypeofPayment.DoesNotExist:
            return render(
                request,
                "primary/createpayment.html",
                {"message": "Invalid payment type.", "types": types, "levels": levels},
            )

        # ------------------------------------------------------------------ #
        # 4. Create the payment record in CreatePayment
        # ------------------------------------------------------------------ #
        payment = CreatePayment.objects.create(
            name=name,
            description=description,
            amount=amount,
            TypeofPayment=payment_type,
        )

        # ------------------------------------------------------------------ #
        # 5. Handle selected class levels
        # ------------------------------------------------------------------ #
        level_names = []  # for message & student filtering

        if level_ids:                                    # some levels ticked
            selected_levels = ClassLevel.objects.filter(id__in=level_ids)
            payment.levels.set(selected_levels)          # many-to-many link
            level_names = [lvl.name for lvl in selected_levels]

        # ------------------------------------------------------------------ #
        # 6. Apply to matching students (single SQL update)
        # ------------------------------------------------------------------ #
        students_qs = Student.objects.filter(student_student_status="active")
        if level_names:                                  # filter by level name
            students_qs = students_qs.filter(level__name__in=level_names)

        # Create payments for each student
        updated_count = 0
        for student in students_qs:
            payment_record = Payment.objects.create(
                transcation_for=payment,  # Correct field name here
                amount=amount,
                typeofPayment=payment_type,
                student=student,  # Assign the student for the payment
                effect='Debit',  # Assuming 'Debit' is the default effect for payments
            )
            updated_count += 1

        # ------------------------------------------------------------------ #
        # 7. Build success message
        # ------------------------------------------------------------------ #
        if level_names:
            message = (
                f"Payment '{name}' of ${amount} applied to {updated_count} "
                f"student(s) in: {', '.join(level_names)}."
            )
        else:
            message = (
                f"Payment '{name}' of ${amount} applied to {updated_count} "
                "student(s) in all levels."
            )

    # ---------------------------------------------------------------------- #
    # 8. Render page (GET or after POST)
    # ---------------------------------------------------------------------- #
    return render(
        request,
        "primary/createpayment.html",
        {"message": message, "types": types, "levels": levels},
    )


@group_required(["admin"])
def payment_receipt(request, invoice_number):
    payment = get_object_or_404(Payment, invoice_number=invoice_number)
    return render(request, "primary/paymentreceipt.html", {"payment": payment})



@group_required(["admin", "clerk"])
def make_paymentother(request):
    """
    Records an individual payment.
    """
    message = ""
    today = timezone.now().date()
    transactions = TypeofPayment.objects.all()  # List of types of payment
    payment_options = CreatePayment.objects.all()  # For the 'Payment For' dropdown

    if request.method == "POST":
        student_id = request.POST.get("student_id", "").strip()
        typeofPayment_id = request.POST.get("typeofPayment")
        amount_raw = request.POST.get("amount")
        method = request.POST.get("method")
        reference = request.POST.get("reference") or None
        payment_for_id = request.POST.get("payment_for")  # ID of the CreatePayment model option
        user_name = request.user.username if request.user.is_authenticated else None

        # ── validate student ───────────────────────────────────────────────
        try:
            student = Student.objects.get(studentid=student_id)
        except Student.DoesNotExist:
            message = f"No student found with ID '{student_id}'."
            return render(request, "primary/makepayment.html", {
                "message": message,
                "types": transactions,
                "payment_options": payment_options,
                "today": today
            })

        # ── validate type of payment ───────────────────────────────────────
        try:
            typeofPayment = TypeofPayment.objects.get(id=typeofPayment_id)
        except TypeofPayment.DoesNotExist:
            message = "Invalid type of payment selected."
            return render(request, "primary/makepayment.html", {
                "message": message,
                "types": transactions,
                "payment_options": payment_options,
                "today": today
            })

        # ── validate / override amount ────────────────────────────────────
        try:
            amount = Decimal(amount_raw)
            if amount <= 0:
                raise ValueError
        except (InvalidOperation, ValueError):
            message = "Enter a valid positive amount."
            return render(request, "primary/makepayment.html", {
                "message": message,
                "types": transactions,
                "payment_options": payment_options,
                "today": today
            })

        # ── validate payment_for (CreatePayment) ─────────────────────────
        try:
            payment_for = CreatePayment.objects.get(id=payment_for_id)
        except CreatePayment.DoesNotExist:
            message = "Invalid 'Payment For' option selected."
            return render(request, "primary/makeotherpayment.html", {
                "message": message,
                "types": transactions,
                "payment_options": payment_options,
                "today": today
            })

        # ── create Payment record ────────────────────────────────────────
        payment = Payment.objects.create(
    student        = student,
    amount         = amount,
    date           = today,
    method         = method,
    reference      = reference,
    processed_by   = user_name,
    typeofPayment  = typeofPayment,
    transcation_for= payment_for,
    effect         = "Credit",          
)

        # ── update student balance in a single DB hit ───────────────────
        student.fees_balance = F("fees_balance") - amount
        student.save(update_fields=["fees_balance"])

        # redirect to receipt (assumes payment_receipt view exists)
        return redirect("primary:paymentreceipt", invoice_number=payment.invoice_number)

    # GET request (initial page load)
    return render(request, "primary/makeotherpayment.html", {
        "types": transactions,
        "payment_options": payment_options,
        "today": today,
        "message": message
    })


@group_required(["admin", "clerk"])
def make_payment(request):
    message = ""
    types   = TypeofPayment.objects.all()
    today   = timezone.now().date()

    if request.method == "POST":
        student_id    = request.POST.get("student_id", "").strip()
        type_id       = request.POST.get("typeofPayment")
        amount_raw    = request.POST.get("amount")
        date          = request.POST.get("date") or today
        method        = request.POST.get("method")
        reference     = request.POST.get("reference")
        processed_by  = request.user.username if request.user.is_authenticated else None

        # --- validate student -------------------------------------------------
        try:
            student = Student.objects.get(studentid=student_id)
        except Student.DoesNotExist:
            message = f"No student found with ID '{student_id}'."
            return render(request, "primary/makepayment.html", {
                "types": types, "today": today, "message": message
            })

        # --- validate payment type -------------------------------------------
        try:
            payment_type = TypeofPayment.objects.get(id=type_id)
        except TypeofPayment.DoesNotExist:
            message = "Invalid payment type selected."
            return render(request, "primary/makepayment.html", {
                "types": types, "today": today, "message": message
            })

        # --- validate & convert amount ---------------------------------------
        try:
            amount = Decimal(amount_raw)
            if amount <= 0:
                raise ValueError
        except (ValueError, TypeError):
            message = "Enter a valid positive amount."
            return render(request, "primary/makepayment.html", {
                "types": types, "today": today, "message": message
            })

        # --- generate invoice number -----------------------------------------
        prefix  = payment_type.name[0].upper()
        latest  = Payment.objects.filter(invoice_number__startswith=prefix).order_by("-invoice_number").first()
        next_no = int(latest.invoice_number[1:]) + 1 if latest else 1
        invoice_number = f"{prefix}{next_no:06d}"

        # --- create payment ---------------------------------------------------
        payment = Payment.objects.create(
            invoice_number = invoice_number,
            student        = student,
            typeofPayment  = payment_type,
            amount         = amount,
            date           = date,
            method         = method,
             effect         = "Credit",  
            reference      = reference,
            processed_by   = processed_by
        )

        # --- update student balance ------------------------------------------
        student.fees_balance -= amount
        student.save()

        return redirect("primary:paymentreceipt", invoice_number=invoice_number)

    # GET request
    return render(request, "primary/makepayment.html", {
        "types": types, "today": today, "message": message
    })


@group_required(["admin"])
def set_fees(request):
    """
    - Creates a Fee entry (amount, year, term)
    - Charges each active student by:
        • Increasing their balance
        • Creating a 'Debit' Payment record
    """
    message = ""
    updated_students = 0

    if request.method == "POST":
        amount_raw = request.POST.get("amount")
        year       = request.POST.get("year")
        term       = request.POST.get("term")

        # Validate amount
        try:
            amount = Decimal(amount_raw)
            if amount <= 0:
                raise ValueError
        except (ValueError, TypeError):
            message = "Please enter a positive numeric amount."
            return render(request, "primary/setfees.html", {"message": message})

        # Check if fee already exists
        if Fee.objects.filter(year=year, term=term).exists():
            message = f"Fee for Year {year} Term {term} already exists."
        else:
            # Create the Fee record
            fee = Fee.objects.create(amount=amount, year=year, term=term)

            # Get or create the 'Charged' payment type
            try:
                charged_type = TypeofPayment.objects.get(name__iexact="Charged")
            except TypeofPayment.DoesNotExist:
                message = "Error: 'Charged' TypeofPayment not found. Please create it first."
                return render(request, "primary/setfees.html", {"message": message})

            # Loop through active students and:
            #   1. increase their balance
            #   2. create a 'Debit' Payment record
            students_qs = Student.objects.filter(student_status="active")

            for student in students_qs:
                student.fees_balance += amount
                student.save(update_fields=["fees_balance"])

                Payment.objects.create(
                    student        = student,
                    amount         = amount,
                    date           = timezone.now().date(),
                    typeofPayment  = charged_type,
                    effect         = "Debit",
                    processed_by   = request.user.username if request.user.is_authenticated else "System"
                )

                updated_students += 1

            message = (
                f"Fee of ${amount} for Year {year} Term {term} has been set. "
                f"{updated_students} student balances updated and logged."
            )

    return render(request, "primary/setfees.html", {"message": message})



@group_required(["admin"])
def student_profile(request):
    student = None
    message = None

    if request.method == 'POST':
        studentid = request.POST.get('studentid').strip()
        try:
            student = Student.objects.get(studentid=studentid)
        except Student.DoesNotExist:
            message = f"No student found with ID '{studentid}'"

    return render(request, 'primary/studentprofile.html', {
        'student': student,
        'message': message
    })



@group_required(["admin", "clerk"])
def fees_dashboard(request):
    return render(request, 'primary/feesdashboard.html')


@group_required(["admin", "secretary"])
def register_student(request):
    message = None

    if request.method == 'POST':
        # Collect form data
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        date_of_birth = request.POST.get('date_of_birth')
        gender = request.POST.get('gender')
        nationality = request.POST.get('nationality', 'Zimbabwean')
        boarding_status = request.POST.get('boarding_status', 'day scholar')
        level = request.POST.get('level')
        class_name = request.POST.get('class_name')
        medical_conditions = request.POST.get('medical_conditions')
        behavioural_notes = request.POST.get('behavioural_notes')

        parent_full_name = request.POST.get('parent_full_name')
        parent_last_name = request.POST.get('parent_last_name')
        parent_phone_number = request.POST.get('parent_phone_number')
        parent_email = request.POST.get('parent_email')
        parent_address = request.POST.get('parent_address')
        relationship_to_student = request.POST.get('relationship_to_student')
        parent_occupation = request.POST.get('parent_occupation')
        parent_gender = request.POST.get('parent_gender')
        previous_results = request.POST.get('previous_results')

      

        # Save the student
        student = Student(
            first_name=first_name,
            last_name=last_name,
            date_of_birth=date_of_birth,
            gender=gender,
            nationality=nationality,
            boarding_status=boarding_status,
            level=level,
            class_name=class_name,
            medical_conditions=medical_conditions,
            behavioural_notes=behavioural_notes,
            parent_full_name=parent_full_name,
            parent_last_name=parent_last_name,
            parent_phone_number=parent_phone_number,
            parent_email=parent_email,
            parent_address=parent_address,
            relationship_to_student=relationship_to_student,
            parent_occupation=parent_occupation,
            parent_gender=parent_gender,
            previous_results =previous_results,
        )
        student.save()

        message = f"Student {student.first_name} {student.last_name} registered successfully as {student.studentid}."

    return render(request, 'primary/registerstudent.html', {'message': message})
