from django.db import models
from django.contrib.auth.models import AbstractUser
import datetime
import re




class ClassLevel(models.Model):
    level = models.IntegerField(unique=True)

    def __str__(self):
        return "Form"+" "+str(self.level)

class Payment(models.Model):
    invoice_number = models.CharField(max_length=20, unique=True)
    student = models.ForeignKey('Student', on_delete=models.CASCADE, related_name='payments')
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    date = models.DateField(default=datetime.date.today)
    method = models.CharField(max_length=50, blank=True, null=True)  # e.g., 'Cash', 'Bank Transfer', 'Mobile Money'
    processed_by = models.CharField(max_length=100, blank=True, null=True)  # Name of the person processing the payment
    reference=models.CharField(max_length=100, blank=True, null=True)  # Optional reference number for the payment
    typeofPayment = models.ForeignKey('TypeofPayment', on_delete=models.CASCADE, related_name='payments', blank=True, null=True)   
    levels = models.ManyToManyField('ClassLevel', blank=True)
    effect= models.CharField(max_length=50, default='Debit')

    transcation_for=models.ForeignKey('CreatePayment', on_delete=models.CASCADE, related_name='payments', blank=True, null=True)    
    def _generate_invoice_number(self):
        """
        Generates an invoice number:
        • First letter of TypeOfPayment name (defaults to 'X' if not set)
        • 6-digit incremental counter, scoped to that prefix
        """
        prefix = (self.typeofPayment.name[0] if self.typeofPayment else 'X').upper()

        # Find the latest invoice with this prefix
        latest = (
            Payment.objects
            .filter(invoice_number__startswith=prefix)
            .order_by('-invoice_number')
            .first()
        )

        if latest:
            # Extract numeric part and increment
            match = re.search(rf'^{prefix}(\d+)$', latest.invoice_number)
            next_number = int(match.group(1)) + 1 if match else 1
        else:
            next_number = 1

        return f"{prefix}{next_number:06d}"

    def save(self, *args, **kwargs):
        if not self.invoice_number:
            self.invoice_number = self._generate_invoice_number()
        super().save(*args, **kwargs)

    def __str__(self):
        return (f"Payment {self.invoice_number} – "
                f"{self.effect} {self.student.first_name} {self.student.last_name} – "
                f"${self.amount:.2f} on {self.date}")
class TypeofPayment(models.Model):
    name = models.CharField(max_length=100, unique=True)
    description = models.TextField(blank=True, null=True)

    def __str__(self):
        return self.name
    
class CreatePayment(models.Model):
    name= models.CharField(max_length=100)
    description = models.TextField(blank=True, null=True)
    amount = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    TypeofPayment = models.ForeignKey(TypeofPayment, on_delete=models.CASCADE, related_name='create_payments', blank=True, null=True)

    def __str__(self):
        return f"{self.name} - ${self.amount:.2f} ({self.TypeofPayment.name if self.TypeofPayment else 'No Type'})"
class Fee(models.Model):
    amount=models.DecimalField(max_digits=10, decimal_places=2)
    year=models.IntegerField(default=datetime.date.today().year)
    term=models.IntegerField()  # 1 for Term 1, 2 for Term 2, 3 for Term 3

    def __str__(self):
        return f"{self.year} Term {self.term} - ${self.amount:.2f}"
    
class Student(models.Model):
    studentid = models.CharField(max_length=25, unique=True)
    first_name = models.CharField(max_length=255)
    last_name = models.CharField(max_length=255)
    level=models.IntegerField()
    class_name=models.CharField(max_length=3)
    gender=models.CharField(max_length=8)
    date_of_registration = models.DateField(default=datetime.date.today)
    boarding_status= models.CharField(max_length=10, default='day scholar')
    student_status = models.CharField(max_length=10, default='active')
    date_of_birth = models.DateField()  
    nationality=models.CharField(max_length=50, default='Zimbabwean')
    medical_conditions = models.TextField(blank=True, null=True)
    previous_results=models.TextField(blank=True, null=True)
    behavioural_notes = models.TextField(blank=True, null=True)
    fees_balance = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)

    ##PARENTAL INFORMATION

    parent_full_name = models.CharField(max_length=255, blank=True, null=True)
    parent_last_name = models.CharField(max_length=255, blank=True, null=True)
    parent_address = models.CharField(max_length=255, blank=True, null=True)
    relationship_to_student = models.CharField(max_length=50, blank=True, null=True)
    parent_phone_number = models.CharField(max_length=15, blank=True, null=True)
    parent_email = models.EmailField(blank=True, null=True)
    parent_occupation = models.CharField(max_length=100, blank=True, null=True)
    parent_gender= models.CharField(max_length=10, blank=True, null=True)
    
    def generate_studentid(self):
        # Get first three letters of first_name and last_name
        first_part = self.first_name[:3].lower()  # First 3 letters of first name
        last_part = self.last_name[:3].lower()    # First 3 letters of last name
        
        # Start with 'S'
        base_studentid = f"S{last_part}{first_part}"

        # Check if studentid already exists, and if so, increment the number
        counter = 1
        while Student.objects.filter(studentid=f"{base_studentid}{counter:02d}").exists():
            counter += 1

        return f"{base_studentid}{counter:02d}"

    def save(self, *args, **kwargs):
        if not self.studentid:
            self.studentid = self.generate_studentid()
        
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.first_name} {self.last_name} ({self.studentid})"