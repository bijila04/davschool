from django.contrib import admin

from .models import Student, Fee,Payment, TypeofPayment,ClassLevel,CreatePayment

admin.site.register(Student)
admin.site.register(Fee)
admin.site.register(Payment)
admin.site.register(TypeofPayment)
admin.site.register(ClassLevel)
admin.site.register(CreatePayment)
# Register your models here.
