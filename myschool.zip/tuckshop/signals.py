from django.db.models.signals import post_save
from django.dispatch import receiver
from .models import Sale, UniformItem

@receiver(post_save, sender=Sale)
def reduce_stock(sender, instance, created, **kwargs):
    if created:
        item = instance.item
        item.quantity = max(0, item.quantity - instance.qty)
        item.save(update_fields=["quantity"])
