import json, calendar
from decimal import Decimal
from datetime import datetime
from django.db.models import Sum
from django.shortcuts import render, redirect, get_object_or_404
from core.views import group_required            # you already wrote this
from .models import UniformItem, Sale
from django.shortcuts import render

# Create your views here.
from django.shortcuts import render, redirect
from django.shortcuts import render, get_object_or_404

from django.contrib import messages
from django.db.models import F
from django.db.models import Sum
from django.contrib.auth import authenticate, login
from datetime import datetime

from django.shortcuts import render, redirect
from django.contrib.auth import logout


def logout_view(request):
    logout(request)
    return redirect('primary:login')

# primary/views.py

from django.contrib.auth.models import User, Group


def add_stock_manual(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        description = request.POST.get('description', '')
        buying_price = request.POST.get('buying_price')
        selling_price = request.POST.get('selling_price')
        quantity = request.POST.get('quantity')
        low_stock_level = request.POST.get('low_stock_level', 5)

        # Basic validation
        if not name or not buying_price or not selling_price or not quantity:
            messages.error(request, "Please fill in all required fields.")
        else:
            try:
                item = UniformItem.objects.create(
                    name=name,
                    description=description,
                    buying_price=buying_price,
                    selling_price=selling_price,
                    quantity=quantity,
                    low_stock_level=low_stock_level
                )
                messages.success(request, f"{item.name} added successfully.")
                return redirect('tuckshop:stock')
            except Exception as e:
                messages.error(request, f"Error: {str(e)}")

    return render(request, 'tuckshop/add_stock_manual.html')

def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            if user.groups.filter(name='admin').exists():
                return redirect('tuckshop:stock')
            elif user.groups.filter(name='clerk').exists():
                return redirect('tuckshop:stock')
        
            else:
                return redirect('core:index')
        else:
            messages.error(request, 'Invalid username or password.')

    return render(request, 'tuckshop/login.html')



@group_required(["admin", "clerk"])
def stock_list(request):
    items = UniformItem.objects.all().order_by("name")
    low_items = items.filter(quantity__lte=F("low_stock_level"))
    return render(request, "tuckshop/stock_list.html",
                  {"items": items, "low_items": low_items})


@group_required(["admin", "clerk"])
def add_sale(request, item_id):
    item = get_object_or_404(UniformItem, id=item_id)
    if request.method == "POST":
        qty = int(request.POST["qty"])
        Sale.objects.create(
            item=item,
            qty=qty,
            processed_by=request.user.username
        )
        return redirect("tuckshop:stock")
    return render(request, "tuckshop/add_sale.html", {"item": item})


@group_required(["admin"])                                # only admins see money report
def revenue_report(request):
    """Year-to-date revenue & profit by month."""
    year = datetime.now().year
    qs = (Sale.objects
                .filter(sold_at__year=year)
                .values("sold_at__month")
                .annotate(
                    revenue=Sum(F("qty") * F("item__selling_price")),
                    cost   =Sum(F("qty") * F("item__buying_price")),
                )
                .order_by("sold_at__month"))

    # Build lists for the chart
    months      = [calendar.month_name[m] for m in range(1, 13)]
    revenue     = [0] * 12
    profit      = [0] * 12
    for row in qs:
        idx = row["sold_at__month"] - 1
        revenue[idx] = float(row["revenue"] or 0)
        profit[idx]  = float((row["revenue"] or 0) - (row["cost"] or 0))

    return render(request, "tuckshop/report.html",
                  {"months": json.dumps(months),
                   "revenue": json.dumps(revenue),
                   "profit": json.dumps(profit)})


@group_required(["admin", "clerk"])
def restock_item(request, item_id):
    item = get_object_or_404(UniformItem, id=item_id)

    if request.method == "POST":
        qty = int(request.POST["qty"])

        if qty <= 0:
            messages.error(request, "Quantity must be positive.")
        else:
            item.quantity = F("quantity") + qty
            item.save(update_fields=["quantity"])
            item.refresh_from_db()  # to reflect updated quantity immediately
            messages.success(request, f"Restocked {qty} × {item.name}.")

        return redirect("tuckshop:stock")

    return render(request, "tuckshop/restock.html", {"item": item})
