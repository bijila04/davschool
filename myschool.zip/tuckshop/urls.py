from django.urls import path
from . import views

app_name = "tuckshop"

urlpatterns = [
    path("stock/", views.stock_list, name="stock"),
    path("sell/<int:item_id>/", views.add_sale, name="addsale"),
    path("report/", views.revenue_report, name="report"),
    path("login/", views.login_view, name="login"),
        path('stock/add/', views.add_stock_manual, name='add_stock_manual'), 
        path("restock/<int:item_id>/", views.restock_item, name="restock_item"),

]
