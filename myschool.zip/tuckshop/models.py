from decimal import Decimal
from django.db import models
from django.utils import timezone

class UniformItem(models.Model):
    name        = models.CharField(max_length=120, unique=True)
    description = models.TextField(blank=True)
    buying_price  = models.DecimalField(max_digits=10, decimal_places=2)
    selling_price = models.DecimalField(max_digits=10, decimal_places=2)
    quantity       = models.PositiveIntegerField(default=0)
    low_stock_level = models.PositiveIntegerField(default=5)   # alert when ≤ this

    def __str__(self):
        return self.name

    @property
    def is_low(self):
        return self.quantity <= self.low_stock_level


class Sale(models.Model):
    item      = models.ForeignKey(UniformItem, on_delete=models.PROTECT)
    qty       = models.PositiveIntegerField()
    sold_at   = models.DateTimeField(default=timezone.now)
    processed_by = models.CharField(max_length=100, blank=True, null=True)

    @property
    def revenue(self) -> Decimal:
        return self.item.selling_price * self.qty

    @property
    def cost(self) -> Decimal:
        return self.item.buying_price * self.qty

    @property
    def profit(self) -> Decimal:
        return self.revenue - self.cost
