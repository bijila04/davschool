from django.contrib import admin
from django.utils.html import format_html
from .models import UniformItem, Sale

@admin.display(description="Quantity")
def coloured_qty(obj):
    colour = "#e11d48" if obj.is_low else "#15803d"
    return format_html('<span style="color:{}; font-weight:700;">{}</span>', colour, obj.quantity)

@admin.register(UniformItem)
class UniformItemAdmin(admin.ModelAdmin):
    list_display = ("name", coloured_qty, "buying_price", "selling_price", "low_stock_level")

@admin.register(Sale)
class SaleAdmin(admin.ModelAdmin):
    list_display = ("item", "qty", "sold_at", "revenue", "profit")
