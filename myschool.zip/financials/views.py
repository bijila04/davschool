import calendar, json
from datetime import date, datetime

from django.db.models import Sum, F
from django.shortcuts import render, redirect
from django.contrib import messages

from core.views import group_required          # you already have this
from core.models     import Payment   as HighPayment
from primary.models  import Payment   as PrimPayment
from tuckshop.models import Sale
from .models         import OtherRevenue, OtherExpense
from django.contrib.auth import authenticate, login



from django.contrib.auth.models import User, Group


def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            if user.groups.filter(name='admin').exists():
                return redirect('financials:dashboard')
            elif user.groups.filter(name='clerk').exists():
                 return redirect('financials:dashboard')
            
            else:
                return redirect('core:index')
        else:
            messages.error(request, 'Invalid username or password.')

    return render(request, 'core/login.html')


def _month_labels():
    return [calendar.month_name[m] for m in range(1, 13)]


@group_required(["admin"])                # full picture is only for admins
def dashboard(request):
    year = date.today().year

    # ------------------------------------------------------------------ #
    # 1.  Student fees actually PAID  (Credits only)
    # ------------------------------------------------------------------ #
    fee_qs = (
        list(
            HighPayment.objects.filter(effect="Credit", date__year=year)
            .values("date__month")
            .annotate(total=Sum("amount"))
        )
        + list(
            PrimPayment.objects.filter(effect="Credit", date__year=year)
            .values("date__month")
            .annotate(total=Sum("amount"))
        )
    )
    fees_by_month = {row["date__month"]: row["total"] for row in fee_qs}

    # ------------------------------------------------------------------ #
    # 2.  Tuck-shop revenue & cost
    # ------------------------------------------------------------------ #
    sale_qs = (
        Sale.objects.filter(sold_at__year=year)
        .values("sold_at__month")
        .annotate(
            revenue=Sum(F("qty") * F("item__selling_price")),
            cost   =Sum(F("qty") * F("item__buying_price")),
        )
    )
    sales_rev = {row["sold_at__month"]: row["revenue"] for row in sale_qs}
    sales_cost = {row["sold_at__month"]: row["cost"] for row in sale_qs}

    # ------------------------------------------------------------------ #
    # 3.  Other revenue / expenses
    # ------------------------------------------------------------------ #
    other_rev = (
        OtherRevenue.objects.filter(date__year=year)
        .values("date__month")
        .annotate(total=Sum("amount"))
    )
    other_exp = (
        OtherExpense.objects.filter(date__year=year)
        .values("date__month")
        .annotate(total=Sum("amount"))
    )

    other_rev_by_month = {r["date__month"]: r["total"] for r in other_rev}
    other_exp_by_month = {e["date__month"]: e["total"] for e in other_exp}

    # ------------------------------------------------------------------ #
    # 4.  Assemble monthly numbers
    # ------------------------------------------------------------------ #
    months   = _month_labels()
    revenue  = []
    expense  = []

    for m in range(1, 13):
        rev = (fees_by_month.get(m, 0) or 0) + (sales_rev.get(m, 0) or 0) + (other_rev_by_month.get(m, 0) or 0)
        exp = (sales_cost.get(m, 0)  or 0) + (other_exp_by_month.get(m, 0) or 0)
        revenue.append(float(rev))
        expense.append(float(exp))

    profit = [r - e for r, e in zip(revenue, expense)]

    context = {
        "months":   json.dumps(months),
        "revenue":  json.dumps(revenue),
        "expense":  json.dumps(expense),
        "profit":   json.dumps(profit),
        "year": year,
    }
    return render(request, "financials/dashboard.html", context)


@group_required(["admin", "clerk"])
def add_revenue(request):
    if request.method == "POST":
        src   = request.POST.get("source", "").strip()
        amt   = request.POST.get("amount")
        desc  = request.POST.get("description", "")
        try:
            amt = float(amt)
            if amt <= 0:
                raise ValueError
            OtherRevenue.objects.create(source=src, amount=amt, description=desc)
            messages.success(request, "Revenue recorded.")
            return redirect("financials:dashboard")
        except ValueError:
            messages.error(request, "Enter a positive amount.")
    return render(request, "financials/add_revenue.html")


@group_required(["admin"])
def add_expense(request):
    if request.method == "POST":
        cat   = request.POST.get("category", "").strip()
        amt   = request.POST.get("amount")
        desc  = request.POST.get("description", "")
        try:
            amt = float(amt)
            if amt <= 0:
                raise ValueError
            OtherExpense.objects.create(category=cat, amount=amt, description=desc)
            messages.success(request, "Expense recorded.")
            return redirect("financials:dashboard")
        except ValueError:
            messages.error(request, "Enter a positive amount.")
    return render(request, "financials/add_expense.html")
