from django.urls import path
from . import views

app_name = "financials"

urlpatterns = [
    path("",                       views.dashboard,       name="dashboard"),
    path("add-revenue/",           views.add_revenue,     name="addrevenue"),
    path("add-expense/",           views.add_expense,     name="addexpense"),
    path("login/",                  views.login_view,      name="login"),
]
