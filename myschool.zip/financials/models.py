from decimal import Decimal
from django.db import models
from django.utils import timezone


class OtherRevenue(models.Model):
    """
    Anything that brings in cash but isn’t a student payment
    or a tuck-shop sale (e.g. hall hire, donations).
    """
    date        = models.DateField(default=timezone.now)
    source      = models.CharField(max_length=120)
    description = models.TextField(blank=True)
    amount      = models.DecimalField(max_digits=10, decimal_places=2)

    def __str__(self):
        return f"{self.source} – ${self.amount}"


class OtherExpense(models.Model):
    """
    Anything the school spends cash on that isn’t covered elsewhere.
    """
    date        = models.DateField(default=timezone.now)
    category    = models.CharField(max_length=120)
    description = models.TextField(blank=True)
    amount      = models.DecimalField(max_digits=10, decimal_places=2)

    def __str__(self):
        return f"{self.category} – ${self.amount}"
