from django.contrib import admin

# Register your models here.
from .models import OtherExpense, OtherRevenue
admin.site.register(OtherRevenue)
admin.site.register(OtherExpense)